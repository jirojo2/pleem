# Testing application for the backend team

To install, simply run `bower install` within this folder to get the dependencies in order,
then go to the path: `/test-angular/index.html`